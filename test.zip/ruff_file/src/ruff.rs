// Define a trait named 'Animal'
trait Animal {
    // Method signature for 'sound'
    fn make_sound(&self){
        println!("kksk");
    }
    fn make(&self);

}

// Define a struct named 'Dog'
struct Dog;

// Implement the 'Animal' trait for 'Dog'
impl Animal for Dog {
    // Implement the 'make_sound' method for 'Dog'
    fn make(&self)
    {
        println!("Woof!");
    }
}

fn main() {
    let dog = Dog;
    dog.make_sound(); // Output: Woof!
    dog.make();
}
